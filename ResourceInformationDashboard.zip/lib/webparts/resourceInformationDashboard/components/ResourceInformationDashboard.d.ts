import * as React from 'react';
import type { IResourceInformationDashboardProps } from './IResourceInformationDashboardProps';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/items/get-all";
import '../assets/CustomStyle.css';
export interface IResourceInformation {
    Department: string;
    Designation: string;
    EmployeeName: string;
    Experience: string;
    Skills_Advanced: string;
    Skills_Basic: string;
    Skills_Moderate: string;
    ID: number;
}
export interface ISkillData {
    Skills: string;
    ID: number;
}
interface State {
    data: IResourceInformation[];
    skillsData: ISkillData[];
    tabIndex: number;
    isSkillsFilterOpen: boolean;
    filterType: 'basic' | 'moderate' | 'advanced';
    tempSelectedSkills: string[];
    appliedBasicSkillsFilter: string[];
    appliedModerateSkillsFilter: string[];
    appliedAdvancedSkillsFilter: string[];
    basicSkillsSearchText: string;
    moderateSkillsSearchText: string;
    advancedSkillsSearchText: string;
    showSkillsDropdown: boolean;
    isLoadingResources: boolean;
}
export default class ResourceInformationDashboard extends React.Component<IResourceInformationDashboardProps, State> {
    private sp;
    constructor(props: IResourceInformationDashboardProps);
    componentDidMount(): Promise<void>;
    private fetchResourceData;
    private fetchSkillsData;
    private getUniqueSkills;
    private getFilteredData;
    private handleOpenSkillsFilter;
    private handleCloseSkillsFilter;
    private handleApplySkillsFilter;
    private handleClearSkillsFilter;
    private handleSkillToggle;
    private handleSearchInputChange;
    private renderSkillsFilterDialog;
    private handleAddNewResource;
    private handleAddNewSkill;
    private handleEditResource;
    private handleDeleteResource;
    private handleDeleteSkill;
    private handleEditSkill;
    private handleViewResource;
    render(): React.ReactElement<IResourceInformationDashboardProps>;
}
export {};
//# sourceMappingURL=ResourceInformationDashboard.d.ts.map