declare const styles: {
    resourceInformationDashboard: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=ResourceInformationDashboard.module.scss.d.ts.map