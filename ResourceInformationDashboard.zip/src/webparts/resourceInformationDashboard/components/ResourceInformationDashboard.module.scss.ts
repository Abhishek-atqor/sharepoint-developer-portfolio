/* tslint:disable */
require("./ResourceInformationDashboard.module.css");
const styles = {
  resourceInformationDashboard: 'resourceInformationDashboard_fadae2a2',
  teams: 'teams_fadae2a2',
  welcome: 'welcome_fadae2a2',
  welcomeImage: 'welcomeImage_fadae2a2',
  links: 'links_fadae2a2'
};

export default styles;
/* tslint:enable */